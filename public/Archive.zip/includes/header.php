<?php
/**
 * Pentagon Quest — Shared Header Component
 */
require_once __DIR__ . '/bootstrap.php';

use App\Helpers\Path;
use App\Services\HomeMediaService;
use App\Services\DestinationService;

$base = !empty($base_path) ? rtrim($base_path, '/') . '/' : Path::baseUrl();
$cssPath = Path::publicPath('assets', 'css', 'style.css');
$cssVersion = is_file($cssPath) ? filemtime($cssPath) : time();
$homeMediaService = new HomeMediaService();
$siteLogo = $homeMediaService->logoPath();
$showPosterNav = $homeMediaService->showPosters() && $homeMediaService->activePosters() !== [];
$navDestinations = (new DestinationService())->getActive();

// Absolute site URL, needed because social crawlers (Facebook/WhatsApp/X/LinkedIn)
// ignore relative og:url / og:image values.
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['SERVER_PORT'] ?? '') == 443 ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$siteOrigin = $scheme . '://' . $host;
$absoluteBase = $siteOrigin . $base;

$ogTitle = trim((string) ($page_title ?? 'Pentagon Quest'));
$ogDescription = trim((string) ($page_description ?? 'Pentagon Quest — authentic African safari expeditions, tours, and travel experiences.'));

// Any page can set $page_image (relative path or absolute URL) before including
// this header — e.g. a blog post's featured image or a tour's cover photo.
// Falls back to the site logo so every shared link still carries a thumbnail.
$rawPageImage = trim((string) ($page_image ?? ''));
if ($rawPageImage === '') {
    $rawPageImage = $siteLogo;
}
$ogImage = str_starts_with($rawPageImage, 'http://') || str_starts_with($rawPageImage, 'https://')
    ? $rawPageImage
    : $absoluteBase . ltrim($rawPageImage, '/');

$ogUrl = $siteOrigin . ($_SERVER['REQUEST_URI'] ?? $base);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo htmlspecialchars($page_title); ?> | Pentagon Quest</title>
  <meta name="description" content="<?php echo htmlspecialchars($page_description); ?>">
  <link rel="canonical" href="<?php echo htmlspecialchars($ogUrl, ENT_QUOTES, 'UTF-8'); ?>">

  <!-- Open Graph (Facebook, WhatsApp, LinkedIn, Slack, etc.) -->
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="Pentagon Quest">
  <meta property="og:title" content="<?php echo htmlspecialchars($ogTitle, ENT_QUOTES, 'UTF-8'); ?>">
  <meta property="og:description" content="<?php echo htmlspecialchars($ogDescription, ENT_QUOTES, 'UTF-8'); ?>">
  <meta property="og:url" content="<?php echo htmlspecialchars($ogUrl, ENT_QUOTES, 'UTF-8'); ?>">
  <meta property="og:image" content="<?php echo htmlspecialchars($ogImage, ENT_QUOTES, 'UTF-8'); ?>">
  <meta property="og:image:secure_url" content="<?php echo htmlspecialchars($ogImage, ENT_QUOTES, 'UTF-8'); ?>">

  <!-- Twitter/X Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?php echo htmlspecialchars($ogTitle, ENT_QUOTES, 'UTF-8'); ?>">
  <meta name="twitter:description" content="<?php echo htmlspecialchars($ogDescription, ENT_QUOTES, 'UTF-8'); ?>">
  <meta name="twitter:image" content="<?php echo htmlspecialchars($ogImage, ENT_QUOTES, 'UTF-8'); ?>">

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@300;400;500;600;700&family=Tenor+Sans&display=swap" rel="stylesheet">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="<?php echo $base; ?>assets/css/style.css?v=<?php echo $cssVersion; ?>">

  <!-- Favicon -->
  <link rel="icon" type="image/svg+xml" href="<?php echo $base; ?>assets/svgs/favicon.svg">
</head>
<body>

<!-- Modern Centered Navigation -->
<nav class="navbar navbar-pq navbar-expand-lg">
  <div class="container d-flex justify-content-between align-items-center">

    <!-- Brand / Logo -->
    <a class="navbar-brand" href="<?php echo pq_url(); ?>">
      <img src="<?php echo $base . ltrim($siteLogo, '/'); ?>" alt="Pentagon Quest Logo">
    </a>

    <!-- Navigation Pill (Centered on Desktop) -->
    <div class="collapse navbar-collapse justify-content-center" id="mainNav">
      <div class="nav-pill-container">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page === 'index.php') ? 'active' : ''; ?>" href="<?php echo pq_url(); ?>">Home</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle <?php echo ($current_page === 'destinations.php') ? 'active' : ''; ?>" href="<?php echo pq_url('destinations.php'); ?>" role="button" data-bs-toggle="dropdown" aria-expanded="false">Destinations</a>
            <ul class="dropdown-menu pq-dropdown-menu">
              <?php foreach ($navDestinations as $navDestination): ?>
              <li><a class="dropdown-item" href="<?php echo pq_url('destinations.php?destination=' . urlencode($navDestination['name'])); ?>"><?php echo htmlspecialchars($navDestination['name']); ?></a></li>
              <?php endforeach; ?>
              <?php if ($navDestinations !== []): ?>
              <li><hr class="dropdown-divider"></li>
              <?php endif; ?>
              <li><a class="dropdown-item" href="<?php echo pq_url('destinations.php'); ?>">View All Destinations</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page === 'services.php') ? 'active' : ''; ?>" href="<?php echo pq_url('services.php'); ?>">What We Do</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page === 'blog.php') ? 'active' : ''; ?>" href="<?php echo pq_url('blog.php'); ?>">Blog</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page === 'gallery.php') ? 'active' : ''; ?>" href="<?php echo pq_url('gallery.php'); ?>">Gallery</a>
          </li>
          <?php if ($showPosterNav): ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo pq_url('index.php#posters'); ?>">Posters</a>
          </li>
          <?php endif; ?>
          <li class="nav-item">
            <a class="nav-link <?php echo ($current_page === 'about.php') ? 'active' : ''; ?>" href="<?php echo pq_url('about.php'); ?>">Our Story</a>
          </li>
          <li class="nav-item d-lg-none">
            <a class="nav-link <?php echo ($current_page === 'contact.php') ? 'active' : ''; ?>" href="<?php echo pq_url('contact.php'); ?>">Contact Us</a>
          </li>
        </ul>
      </div>
    </div>

    <!-- Contact Button -->
    <div class="d-none d-lg-block">
      <a href="<?php echo pq_url('contact.php'); ?>" class="btn-contact-pill">Contact Us</a>
    </div>

    <!-- Mobile Toggler -->
    <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
    </button>

  </div>
</nav>

<!-- Ankara Accent Strip -->
<div class="ankara-accent"></div>
