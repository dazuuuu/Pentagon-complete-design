<?php

require_once __DIR__ . '/../includes/bootstrap.php';

use App\Core\Auth;
use App\Helpers\Session;
use App\Services\BlogService;

Auth::requireAuth();
Session::start();

$service = new BlogService();
$message = Session::flash('message');
$error = Session::flash('error');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && Session::verifyCsrf($_POST['csrf'] ?? '')) {
  $action = $_POST['action'] ?? '';

  try {
    if ($action === 'update_cover') {
      $service->setCoverImage((int) $_POST['id'], $_FILES['cover_image'] ?? []);
      Session::flash('message', 'Cover image updated.');
    } else {
      $data = [
        'title' => trim($_POST['title'] ?? ''),
        'category' => trim($_POST['category'] ?? ''),
        'excerpt' => trim($_POST['excerpt'] ?? ''),
        'content' => trim($_POST['content'] ?? ''),
        'image_url' => trim($_POST['image_url'] ?? ''),
        'status' => $_POST['status'] ?? 'active',
        'sort_order' => (int) ($_POST['sort_order'] ?? 0),
      ];

      if ($action === 'create') {
        $id = $service->create($data);
        if (!empty($_FILES['cover_image']['name'] ?? '')) {
          $service->setCoverImage($id, $_FILES['cover_image']);
        }
        Session::flash('message', 'Post created.');
      } elseif ($action === 'update') {
        $service->update((int) $_POST['id'], $data);
        Session::flash('message', 'Post updated.');
      } elseif ($action === 'delete') {
        $service->delete((int) $_POST['id']);
        Session::flash('message', 'Post deleted.');
      }
    }
  } catch (\RuntimeException $e) {
    Session::flash('error', $e->getMessage());
  }

  header('Location: blog.php');
  exit;
}

$items = $service->getAll();
$pageTitle = 'Blog';
$currentAdminPage = 'blog';
include __DIR__ . '/includes/header.php';
?>
<div class="content-card p-4">
  <h2 class="mb-3">Manage Blog</h2>
  <?php if ($message): ?><div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
  <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

  <form method="POST" enctype="multipart/form-data" class="row g-2 mb-4">
    <input type="hidden" name="csrf" value="<?php echo Session::csrfToken(); ?>">
    <input type="hidden" name="action" value="create">
    <div class="col-md-5"><input class="form-control" name="title" placeholder="Title" required></div>
    <div class="col-md-3"><input class="form-control" name="category" placeholder="Category" required></div>
    <div class="col-md-2"><input class="form-control" name="sort_order" type="number" placeholder="Sort" value="0"></div>
    <div class="col-md-2"><button class="btn btn-success w-100">Add Post</button></div>
    <div class="col-12"><textarea class="form-control" name="excerpt" placeholder="Short excerpt (shown on the blog grid card)" rows="2"></textarea></div>
    <div class="col-12"><textarea class="form-control rte-content" name="content" placeholder="Full article content (shown on the post's details page)" rows="5"></textarea></div>
    <div class="col-md-6">
      <label class="form-label small text-muted mb-0">Cover image</label>
      <input class="form-control" type="file" name="cover_image" accept="image/*">
    </div>
  </form>

  <table class="table table-sm align-middle">
    <thead><tr><th>Title</th><th>Category</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($items as $item): ?>
      <tr>
        <form method="POST">
          <input type="hidden" name="csrf" value="<?php echo Session::csrfToken(); ?>">
          <input type="hidden" name="action" value="update">
          <input type="hidden" name="id" value="<?php echo (int) $item['id']; ?>">
          <td><input class="form-control form-control-sm" name="title" value="<?php echo htmlspecialchars($item['title']); ?>"></td>
          <td><input class="form-control form-control-sm" name="category" value="<?php echo htmlspecialchars($item['category']); ?>"></td>
          <td>
            <select class="form-select form-select-sm" name="status">
              <option value="active" <?php echo $item['status'] === 'active' ? 'selected' : ''; ?>>active</option>
              <option value="inactive" <?php echo $item['status'] === 'inactive' ? 'selected' : ''; ?>>inactive</option>
            </select>
          </td>
          <td class="d-flex gap-1">
            <input type="hidden" name="excerpt" value="<?php echo htmlspecialchars($item['excerpt'] ?? ''); ?>">
            <input type="hidden" name="content" value="<?php echo htmlspecialchars($item['content'] ?? ''); ?>">
            <input type="hidden" name="image_url" value="<?php echo htmlspecialchars($item['image_url'] ?? ''); ?>">
            <input type="hidden" name="sort_order" value="<?php echo (int) $item['sort_order']; ?>">
            <button class="btn btn-sm btn-primary">Save</button>
        </form>
        <form method="POST" onsubmit="return confirm('Delete this post?');">
          <input type="hidden" name="csrf" value="<?php echo Session::csrfToken(); ?>">
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id" value="<?php echo (int) $item['id']; ?>">
          <button class="btn btn-sm btn-danger">Delete</button>
        </form>
          </td>
      </tr>
      <tr>
        <td colspan="4" class="pt-0">
          <details>
            <summary class="text-muted small">Excerpt, content &amp; cover image</summary>
            <div class="row g-3 my-1">
              <div class="col-md-6">
                <label class="small text-muted mb-1 d-block">Excerpt</label>
                <form method="POST" class="d-flex flex-column gap-2">
                  <input type="hidden" name="csrf" value="<?php echo Session::csrfToken(); ?>">
                  <input type="hidden" name="action" value="update">
                  <input type="hidden" name="id" value="<?php echo (int) $item['id']; ?>">
                  <input type="hidden" name="title" value="<?php echo htmlspecialchars($item['title']); ?>">
                  <input type="hidden" name="category" value="<?php echo htmlspecialchars($item['category']); ?>">
                  <input type="hidden" name="status" value="<?php echo htmlspecialchars($item['status']); ?>">
                  <input type="hidden" name="image_url" value="<?php echo htmlspecialchars($item['image_url'] ?? ''); ?>">
                  <input type="hidden" name="sort_order" value="<?php echo (int) $item['sort_order']; ?>">
                  <textarea class="form-control form-control-sm" name="excerpt" rows="2"><?php echo htmlspecialchars($item['excerpt'] ?? ''); ?></textarea>
                  <textarea class="form-control form-control-sm rte-content" name="content" rows="6" placeholder="Full article content"><?php echo htmlspecialchars($item['content'] ?? ''); ?></textarea>
                  <button class="btn btn-sm btn-outline-primary align-self-start">Save Content</button>
                </form>
              </div>
              <div class="col-md-6">
                <label class="small text-muted mb-1 d-block">Cover image</label>
                <div class="d-flex align-items-center gap-2 mb-2">
                  <?php if (!empty($item['image_url'])): ?>
                  <img src="<?php echo (str_starts_with($item['image_url'], 'http') ? '' : '../') . htmlspecialchars($item['image_url']); ?>" style="width:120px;height:80px;object-fit:cover;border-radius:6px;">
                  <?php endif; ?>
                </div>
                <form method="POST" enctype="multipart/form-data" class="d-flex gap-2 align-items-center">
                  <input type="hidden" name="csrf" value="<?php echo Session::csrfToken(); ?>">
                  <input type="hidden" name="action" value="update_cover">
                  <input type="hidden" name="id" value="<?php echo (int) $item['id']; ?>">
                  <input class="form-control form-control-sm" type="file" name="cover_image" accept="image/*" style="max-width:260px;">
                  <button class="btn btn-sm btn-outline-primary">Replace</button>
                </form>
              </div>
            </div>
          </details>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/6.8.3/tinymce.min.js" referrerpolicy="origin"></script>
<script>
(function () {
  var CSRF = <?php echo json_encode(Session::csrfToken()); ?>;
  var UPLOAD_URL = 'ajax/blog-image-upload.php';
  var LINK_PREVIEW_URL = 'ajax/link-preview.php';

  // --- Custom plugin: Insert Link Card -----------------------------------
  tinymce.PluginManager.add('linkcard', function (editor) {
    editor.ui.registry.addButton('linkcard', {
      icon: 'link',
      tooltip: 'Insert Link Card (with preview)',
      onAction: function () {
        editor.windowManager.open({
          title: 'Insert Link Card',
          body: {
            type: 'panel',
            items: [{ type: 'input', name: 'url', label: 'URL', placeholder: 'https://example.com/article' }]
          },
          buttons: [
            { type: 'cancel', text: 'Cancel' },
            { type: 'submit', text: 'Insert', primary: true }
          ],
          onSubmit: function (api) {
            var data = api.getData();
            var url = (data.url || '').trim();
            if (!url) { api.close(); return; }
            api.disable('submit');

            var fd = new FormData();
            fd.append('csrf', CSRF);
            fd.append('url', url);

            fetch(LINK_PREVIEW_URL, { method: 'POST', body: fd, credentials: 'same-origin' })
              .then(function (r) { return r.json(); })
              .then(function (res) {
                api.close();
                if (res.error) {
                  alert('Could not fetch link preview: ' + res.error);
                  return;
                }
                var img = res.image_url ? '<img src="' + res.image_url + '" alt="">' : '';
                var html = '<div class="link-preview-card" data-url="' + url + '">' +
                  (img ? '<div class="link-preview-card-image">' + img + '</div>' : '') +
                  '<div class="link-preview-card-body">' +
                  '<div class="link-preview-card-title">' + (res.title || url) + '</div>' +
                  (res.description ? '<div class="link-preview-card-desc">' + res.description + '</div>' : '') +
                  '<a href="' + url + '" target="_blank" rel="noopener noreferrer" class="link-preview-card-btn">Visit site</a>' +
                  '</div></div><p>&nbsp;</p>';
                editor.insertContent(html);
              })
              .catch(function () {
                api.close();
                alert('Could not fetch link preview. Please check the URL and try again.');
              });
          }
        });
      }
    });
  });

  // --- Custom plugin: Insert FAQ Section ----------------------------------
  tinymce.PluginManager.add('faqblock', function (editor) {
    editor.ui.registry.addButton('faqblock', {
      icon: 'help',
      tooltip: 'Insert FAQ Section',
      onAction: function () {
        var count = parseInt(prompt('How many FAQ questions do you want to add?', '3'), 10);
        if (!count || count < 1) { return; }
        var html = '<div class="faq-block">';
        for (var i = 1; i <= count; i++) {
          html += '<details><summary>Question ' + i + '</summary><div>Answer goes here.</div></details>';
        }
        html += '</div><p>&nbsp;</p>';
        editor.insertContent(html);
      }
    });
  });

  function initEditor(target) {
    var opts = {
      height: 420,
      menubar: false,
      plugins: 'lists link image media table code wordcount autolink linkcard faqblock',
      toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline forecolor | ' +
        'alignleft aligncenter alignright | bullist numlist | blockquote | ' +
        'link image media table | linkcard faqblock | code',
      block_formats: 'Paragraph=p; Heading 1=h1; Heading 2=h2; Heading 3=h3; Heading 4=h4',
      // Images/videos are resizable by dragging their corner handles once
      // selected in the editor; image_advtab adds explicit width/height
      // fields (with a lock-ratio toggle) to the image dialog too.
      object_resizing: 'img,video,iframe',
      image_advtab: true,
      image_dimensions: true,
      image_class_list: [
        { title: 'Default', value: '' },
        { title: 'Small (25%)', value: 'blog-img-25' },
        { title: 'Medium (50%)', value: 'blog-img-50' },
        { title: 'Large (75%)', value: 'blog-img-75' },
        { title: 'Full width', value: 'blog-img-100' }
      ],
      // Strip the fixed 560x314-style width/height TinyMCE would otherwise
      // bake into inserted <iframe>s, so the CSS aspect-ratio rules for
      // .blog-rich-content iframe make embedded videos responsive.
      media_dimensions: false,
      content_style: 'img,video,iframe{max-width:100%;height:auto;} ' +
        'video,iframe{aspect-ratio:16/9;} ' +
        '.blog-img-25{width:25%;height:auto;} .blog-img-50{width:50%;height:auto;} ' +
        '.blog-img-75{width:75%;height:auto;} .blog-img-100{width:100%;height:auto;}',
      images_upload_url: UPLOAD_URL,
      automatic_uploads: true,
      images_upload_credentials: true,
      images_upload_handler: function (blobInfo) {
        return new Promise(function (resolve, reject) {
          var fd = new FormData();
          fd.append('file', blobInfo.blob(), blobInfo.filename());
          fd.append('csrf', CSRF);
          fetch(UPLOAD_URL, {
            method: 'POST',
            body: fd,
            credentials: 'same-origin',
            headers: { 'X-CSRF-Token': CSRF }
          })
            .then(function (r) { return r.json(); })
            .then(function (res) {
              if (res.location) { resolve(res.location); } else { reject(res.error || 'Upload failed'); }
            })
            .catch(function () { reject('Upload failed'); });
        });
      },
      media_live_embeds: true,
      table_default_attributes: { border: '1' },
      branding: false
    };
    if (typeof target === 'string') {
      opts.selector = target;
    } else {
      opts.target = target;
    }
    tinymce.init(opts);
  }

  document.addEventListener('DOMContentLoaded', function () {
    var topLevel = document.querySelector('form.mb-4 textarea.rte-content');
    if (topLevel) { initEditor(topLevel); }

    // Textareas inside collapsed <details> blocks render at 0 width if
    // initialised while hidden — (re)initialise them when opened instead.
    var initCount = 0;
    document.querySelectorAll('details').forEach(function (det) {
      det.addEventListener('toggle', function () {
        if (!det.open) { return; }
        var ta = det.querySelector('textarea.rte-content');
        if (ta && !ta.dataset.rteInit) {
          ta.dataset.rteInit = '1';
          ta.id = ta.id || ('rte-' + (++initCount) + '-' + Date.now());
          initEditor(ta);
        }
      });
    });
  });
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
